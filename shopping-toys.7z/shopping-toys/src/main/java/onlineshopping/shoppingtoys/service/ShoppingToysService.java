package onlineshopping.shoppingtoys.service;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import onlineshopping.shoppingtoys.dao.ShoppingToysDao;
import onlineshopping.shoppingtoys.model.ToysModel;


@Service
public class ShoppingToysService {
	@Autowired
	ShoppingToysDao shoppingToysDao;
/**
 * Get Toys items
 * @param filterParam
 * @return ToysModel List
 */
 public List<ToysModel> getItems(List<String> filterParam) {
	 
		if(CollectionUtils.isEmpty(filterParam)) {
		return shoppingToysDao.geAllRecords();
		}
		else {
	    return shoppingToysDao.geFiltertRecords(filterParam);
		}
 }
 
}
