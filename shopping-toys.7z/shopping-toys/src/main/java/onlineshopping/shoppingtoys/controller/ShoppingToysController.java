package onlineshopping.shoppingtoys.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import onlineshopping.shoppingtoys.model.ToysModel;
import onlineshopping.shoppingtoys.service.ShoppingToysService;
/**
 * ShoppingToysController used to manage toys online shopping system
 * 
 * @author Vinoth
 *
 */
@RestController
@RequestMapping(path="/display")
public class ShoppingToysController {
	@Autowired
	ShoppingToysService shoppingToysService;
	
	/**
	 * Get Toys list based on conditions from UI
	 * @param filterParam
	 * @return ToysModel List
	 */
	@RequestMapping(path="/getToysList", method=RequestMethod.POST)
	public @ResponseBody List<ToysModel> getToysList (@RequestBody List<String> filterParam) {
		
	return shoppingToysService.getItems(filterParam);  
	}  

}
