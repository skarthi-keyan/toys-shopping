package onlineshopping.shoppingtoys.model;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ToysModel {
	private String id;

	private String name;

	private String category;

	private String description;

	private long price;

	private int  age;
	
	private String imagePath;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	@Override
	public String toString() {
		return "ToysModel [id=" + id + ", name=" + name + ", category=" + category + ", description=" + description
				+ ", price=" + price + ", age=" + age + ", imagePath=" + imagePath + "]";
	}
/**
 * Create ToysModel from  resultSet
 * @param resultSet 
 * @return ToysModel
 * @throws SQLException 
 */
	public static ToysModel formModel(ResultSet resultSet) throws SQLException {
		ToysModel toysModel=new ToysModel();
		toysModel.setAge(resultSet.getInt("age"));
		toysModel.setCategory(resultSet.getString("category"));
		toysModel.setDescription(resultSet.getString("description"));
		toysModel.setId(resultSet.getString("id"));
		toysModel.setImagePath(resultSet.getString("imagePath"));
		toysModel.setName(resultSet.getString("name"));
		toysModel.setPrice(resultSet.getInt("price"));
		return toysModel;
	}

}
