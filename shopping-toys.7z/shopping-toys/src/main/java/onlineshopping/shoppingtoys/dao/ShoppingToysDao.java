package onlineshopping.shoppingtoys.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import onlineshopping.shoppingtoys.model.ToysModel;

@Service
@Slf4j
public class ShoppingToysDao {
	private static String MAIN_QUERY="SELECT * FROM toys";
	/**
	 * Get All records from Toys table
	 * @return ToysModel List
	 */
	public List<ToysModel> geAllRecords() {
		 List<ToysModel> toys=new ArrayList<>();
		try {
			Connection connection=new DBConnection().connect();
			Statement stmt=connection.createStatement();  
			ResultSet rs=stmt.executeQuery(MAIN_QUERY);  
			while(rs.next())  {
				toys.add(ToysModel.formModel(rs));
			}
			connection.close();  
			
		}catch(Exception e) {
			log.error("DB connect failed");
		}
		return toys;
	}
	/**
	 * Get records based of filter param
	 * @param filterParam
	 * @return ToysModel List
	 */
	public List<ToysModel> geFiltertRecords(List<String> filterParam) {
		List<ToysModel> toys=new ArrayList<>();
		StringBuilder condition= new StringBuilder();
		String query = MAIN_QUERY+addAdditionationConditions(filterParam, condition);
		try {
			Connection connection=new DBConnection().connect();
			Statement stmt=connection.createStatement();  
			ResultSet rs=stmt.executeQuery(query);  
			while(rs.next())  {
				toys.add(ToysModel.formModel(rs));
			}
			connection.close();  
			
		}catch(Exception e) {
			log.error("DB connect failed");
		}
		return toys;
	}
	/**
	 * addAdditionationConditions to generate addition query conditions
	 * 
	 * @param filterParam
	 * @param condition
	 * @return subQuery
	 */
	private String addAdditionationConditions(List<String> filterParam, StringBuilder condition) {
		//Age append query
		if(filterParam.contains("below3")) {
			condition.append(condition.toString().isEmpty()?" WHERE age < 3":" AND  age < 3");
		}	
		if(filterParam.contains("between3and6")) {
			condition.append(condition.toString().isEmpty()?" WHERE age BETWEEN 3 AND 6":" AND age BETWEEN 3 AND 6");
		}	
		if(filterParam.contains("between6and10")) {
			condition.append(condition.toString().isEmpty()?" WHERE age BETWEEN 6 AND 10":" AND age BETWEEN 6 AND 10");
		}
		
		//Price append query
		if(filterParam.contains("below250")) {
			condition.append(condition.toString().isEmpty()?" WHERE price < 250":" AND  price < 250");
		}	
		if(filterParam.contains("below1000")) {
			condition.append(condition.toString().isEmpty()?" WHERE price < 1000":" AND  price < 1000");
		}	
		if(filterParam.contains("above1000")) {
			condition.append(condition.toString().isEmpty()?" WHERE price > 1000":" AND  price > 1000");
		}
		return condition.toString();
		
	}

}
