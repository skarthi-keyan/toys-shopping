package onlineshopping.shoppingtoys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingToysApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingToysApplication.class, args);
	}

}
