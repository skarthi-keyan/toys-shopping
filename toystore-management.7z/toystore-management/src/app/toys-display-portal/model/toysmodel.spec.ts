import { ToysModel } from './toysmodel';

describe('ToysModel', () => {
  it('should create an instance', () => {
    expect(new ToysModel()).toBeTruthy();
  });
});
