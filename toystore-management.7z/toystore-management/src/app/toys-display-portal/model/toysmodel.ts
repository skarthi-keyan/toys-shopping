export class ToysModel {
    code?: string;
    name?: string;
    category?: string;
    description?: string;
    price?: number;
    ageGroup?: string;
}
