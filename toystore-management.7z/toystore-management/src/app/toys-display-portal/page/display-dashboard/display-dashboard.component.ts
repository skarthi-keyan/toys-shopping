import { Component, OnInit } from '@angular/core';
import { DisplayDashboardService } from '../../service/display-dashboard.service';
import { ToysModel } from '../../model/toysmodel';

@Component({
  selector: 'app-display-dashboard',
  templateUrl: './display-dashboard.component.html',
  styleUrls: ['./display-dashboard.component.css']
})
export class DisplayDashboardComponent implements OnInit {
  productList: Array<ToysModel> = [];
  filterList: Array<number> = [];
  filterTagList: Array<any> = [];
  removable = true;
  constructor(private displayDashboardService: DisplayDashboardService) { }

  ngOnInit(): void {
    this.getToysList([]);
  }

  filterToys(option: {}) {
    if (this.filterList.includes(option['value'])) {
      const index = this.filterList.indexOf(option['value']);
      this.filterList.splice(index, 1);
      this.filterTagList.splice(index, 1);
    } else{
      this.filterList.push(option['value']);
      this.filterTagList.push({value: option['value'], label: option['label']});
    }
    this.getToysList(this.filterList);
  }

  removeFilter(filterValue: number) {
    const index = this.filterList.indexOf(filterValue);
    this.filterList.splice(index, 1);
    this.filterTagList.splice(index, 1);
    this.getToysList(this.filterList);
  }

  getToysList(filterList: number[]) {
    this.displayDashboardService.getToysList(filterList).subscribe(productList => {
      this.productList = productList;
    });
  }
}
