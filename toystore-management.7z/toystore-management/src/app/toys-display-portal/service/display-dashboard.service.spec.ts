import { TestBed } from '@angular/core/testing';

import { DisplayDashboardService } from './display-dashboard.service';

describe('DisplayDashboardService', () => {
  let service: DisplayDashboardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DisplayDashboardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
