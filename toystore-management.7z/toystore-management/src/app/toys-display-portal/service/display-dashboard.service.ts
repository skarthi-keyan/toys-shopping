import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToysModel } from '../model/toysmodel';

@Injectable({
  providedIn: 'root'
})
export class DisplayDashboardService {
  private baseURL = '/display';
  constructor(private http: HttpClient) { }

  getToysList(filterList: number[]) {
    const filterMap = {
      filterList
    };
    return this.http.post<ToysModel[]>(this.baseURL + '/getToysList', filterList);
  }
}
