import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayDashboardComponent } from './toys-display-portal/page/display-dashboard/display-dashboard.component';

const routes: Routes = [
  {path: '', redirectTo: 'shopping',pathMatch: 'full'},
  {
    path: 'shopping',
    component: DisplayDashboardComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
